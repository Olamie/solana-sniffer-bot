import os
import requests
import telebot
from flask import Flask

BOT_TOKEN = "8279689199:AAEc83YTmN0xgA3E-qgasizvDt9JMUv_h4g"
bot = telebot.TeleBot(BOT_TOKEN)
app = Flask(__name__)

@app.route('/')
def home():
    return "Bot is running!"

def get_tokens():
    url = "https://public-api.birdeye.so/public/token/mostvisited?limit=5"
    headers = {"X-API-KEY": "public"}
    try:
        res = requests.get(url, headers=headers)
        data = res.json().get("data", [])
        return data
    except Exception as e:
        print("Error:", e)
        return []

def format_alert(token):
    name = token.get("name")
    symbol = token.get("symbol")
    price = token.get("price_usd", "N/A")
    url = f"https://birdeye.so/token/{token['address']}?chain=solana"
    return f"🚨 Token: {name} (${symbol})\n💰 Price: ${price}\n📈 [Chart]({url})"

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, "👋 Bot is running and scanning new Solana tokens!")

def scan_and_alert():
    tokens = get_tokens()
    for token in tokens:
        alert = format_alert(token)
        bot.send_message(chat_id="7740818143", text=alert, parse_mode="Markdown")

if __name__ == "__main__":
    import threading, time
    def run_bot():
        while True:
            scan_and_alert()
            time.sleep(60)

    threading.Thread(target=run_bot).start()
    app.run(host="0.0.0.0", port=8080)
